    <footer>
        <p>&copy; 2021 - Dimas Reza Nugraha - 311910431 - TI.19.A.2 - Universitas Pelita Bangsa - Cikarang Selatan</p>
    </footer>
    </div>
</body>
</html>
